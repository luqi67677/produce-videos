# 实现规范

## 单一状态源

- 画幅读取 `video-brief.md`。
- 本机开源模型候选读取 `model-discovery.json`；选中的模型只有 `model-preflight.json.status=pass` 才算可用。
- Qwen 最终声音读取已批准的 `voice-selection.json`，正式旁白不得用命令行参数临时覆盖。
- 三套主题候选读取 `visual-style-options.json`，且必须绑定完整 34 模板索引的 SHA-256，并逐项记录 34 套适配评估后才 shortlist 三套。
- 主题读取 `video-style-theme.json`。
- 旁白与时间轴读取 `narration-contract.json`。
- 正式旁白还必须读取 `audio_path`、`audio_sha256`、实际时长和分段 manifest；渲染前运行 `validate_narration_contract.py --require-timestamps --require-audio`。
- 镜头与素材读取 `shot-readiness.json`。
- 已有音视频的剪辑边界、A/B-roll、素材入点、时间线位置、转场和 `covers` 读取 `edit-decision-list.json`。节拍吸附、渲染与 FCPXML 导出必须消费同一个 EDL。
- 新项目审批状态统一读取 `approval-ledger.json`，旧项目兼容独立 approval JSON；Qwen 声音另读取 `voice-selection.json` 内的用户批准记录。

组件不得自行新增主色、画幅、音色或水印规则。

## 渲染结构

- 页面骨架保持稳定，信息层按旁白语义变化。
- Remotion 或其他时间线实现只从同一个帧时钟派生动画；不用 CSS 实时动画另起一套时间，也不在组件中硬编码画幅。
- 静态分镜是渲染器的输入契约。渲染组件必须读取 `composition_source`、`storyboard_frame_path` 和 `storyboard_state_ids`；不能只读取章节号后自行改成原始素材轮播。
- 视频素材必须读取 `source_window.in_seconds`、`source_window.out_seconds` 和 `action_evidence`。没有入出点或真实动作证据时直接报错，不用循环、重播、随机裁切或自动彩框填满旁白。
- 真实录屏默认只在分镜指定的内容窗口内播放。只有 `composition_source=raw-fullscreen` 且已进入批准分镜时才允许全屏。
- 渲染器不得自动给素材添加装饰外框。`decorative_outer_frame=false` 时任何整页彩色框都属于实现错误；重点标注单独消费 `focus_target`，不复用装饰层。
- 重点标注先在原生关键帧验证坐标，短时进入并及时退出。录屏运动难看时消费 `fallback_visual` 的关键帧或已批准补图，而不是强行动原视频。
- 共享组件负责字幕、安全区、水印和主题 token。
- 正式成片只有一个字幕渲染层；场景底图、分镜帧和素材本身不得再携带一层字幕容器。
- 场景只读取观众可见文字；内部备注、模板名、素材来源、制作说明和镜头编号不得进入渲染文本层。
- 素材路径集中解析；缺失素材应直接报错，不用空白占位继续渲染。
- 生成中间文件时使用项目目录，不写入 Skill 包。
- Qwen 旁白按场景分段生成后拼接；最终视频预检使用 `--narration-contract ... --require-narration-binding` 校验源音频绑定。
- 没有成品旁白时先运行有限范围模型发现。模型下载完成后仍要做最小加载预检和用户选声；“下载成功”不能直接跳到整条旁白生成。
- 风险样片或完整低清预览的渲染入口第一行运行 `validate_render_gate.py --mode sample --narration-contract <实际契约>`；正式母版运行 `--mode full`。传入路径必须与渲染器随后读取的契约是同一个绝对文件，门禁失败必须退出。
- 既有成片修改时，渲染器先读取 `shot-readiness.json.revision_scope`，只生成受影响镜头预览；`preview_approval.approved=true` 且保留镜头与基线一致后才可进入全片渲染。
- 不允许渲染器在门禁之后临时生成一套没有进入分镜审批的覆盖层或镜头定义。分镜帧、修改预览、风险样片和完整低清预览必须先落盘，并由审批账本的对应阶段记录 SHA-256。
- B-roll 只覆盖画面，不改变旁白连续性和整片时长。每个 B-roll 必须消费 EDL/镜头契约中的 `covers`；没有该字段不得进入渲染。
- 转场默认硬切；match cut 和 graphic bridge 必须读取前后状态与连续性锚点。随机缩放、甩镜、故障、光效擦除和无理由 dissolve 不得作为默认过渡。
- 项目存在 `narration-contract-v2.json` 等版本文件时，不得让渲染器读取新版、门禁却隐式校验旧的 `narration-contract.json`。最终 `video_preflight.py` 也必须绑定同一契约。
- 口播声称素材已经保存、同步或进入平台草稿箱时，画面必须消费能证明动作完成的真实状态；设置页或预览页只证明“可以操作”，不能证明“已经完成”。
- 多步骤流程回顾默认保留全部节点，当前节点按口播依次进入强调态，连接线或进度指示同步推进，避免整页一次性出现后长时间静止。
- 完整低清预览前先输出开场、问题、核心证据、重点结论和结尾关键帧；高风险动作需要时再做 4—8 秒样片。用户批准完整预览后才运行正式母版渲染。

## 静帧先行

- 每个项目都要有可重复执行的静帧渲染入口，把真实内容、真实素材和锁定主题渲染为目标原尺寸 PNG；不能依赖临时手写一个无法复现的页面。
- 优先先完成一张完整静态源画面，再在 Remotion 或其他时间线中只动画承担语义的内容层；不要边猜版式边做全片动画。
- 横屏按 1920×1080、竖屏按 1080×1440 原生尺寸渲染。低清预览只能由原生坐标系等比缩放产生，不能用另一套硬编码尺寸重排。
- 同时生成一张约 480 px 宽的缩略图用于信息流检查。原图和缩略图都必须来自同一版源文件。
- HTML/CSS 项目应显式声明中文优先字体栈，并禁止主标题全局大写；品牌词需要独立 class 或数据 token 保持原始大小写。
- 调用 `scripts/validate_layout_preview.py` 检查图片尺寸、品牌 token、标题行数和内部标签泄漏；脚本通过不替代肉眼构图检查。

## 独立封面

每条成片同时交付一张 1080×1440 的 3:4 独立封面；无论主视频横竖，都按信息流重新构图，不裁切视频首帧代替。

封面源文件必须保存用户确认的完整标题，并默认逐字渲染，只调整字号与断行。只有存在用户明确确认记录时才可另设展示标题；只放一个已授权主视觉和必要辅助信息，不渲染页码、模板 slug、制作日期、镜头编号或工作流备注。没有可公开人物时使用真实产品、结果证据或用户授权品牌素材，不生成或夹带发布者个人形象。

## 输出

- 视频默认使用 H.264 High Profile、yuv420p、30fps，并把 MP4 `moov` 原子前置以便快速开始播放；
- 音频默认使用 AAC、48 kHz、双声道、192 kbps 或更高；
- 保留项目源文件、审批记录、成片和质检报告；
- Remotion 项目同时保留源码、锁文件、素材清单和一条可复现渲染命令；用户要求继续编辑时，从同一 EDL 运行 `scripts/export_fcpxml.py` 导出 FCPXML，并列出扁平化 plate。
- 保留模型发现、模型预检、声音选择、三套真实样张及逐项质量复核；
- 不把用户内容或私人资产写回开源 Skill。

## 本地剪辑工具

```bash
# 先用 doctor 找到可用的 Python/STT；必要时指定兼容解释器
python3 scripts/doctor.py
python3 scripts/transcribe_media.py input.mp4 \
  --runtime-python /path/to/compatible-python \
  --backend mlx-whisper --model /path/to/local-whisper-model --language zh

# 有 BGM 时建立节拍网格，再在不切词、不改变总时长的前提下吸附 EDL
python3 scripts/build_beat_grid.py bgm.wav --bpm 120 --output beat-grid.json
python3 scripts/snap_edl_to_beats.py edit-decision-list.json beat-grid.json \
  --transcript input.transcript.json --output edit-decision-list.beat.json

# 从同一 EDL 导出可继续编辑的时间线
python3 scripts/export_fcpxml.py edit-decision-list.json --output timeline.fcpxml
```

## 版本化

- 已交付成片只读，任何修正都生成新版本，不覆盖上一份可用文件。
- 文件名显式写明横屏或竖屏与版本号，不使用 `final-final2` 一类不可追溯名称。
- 新版本保留对应的主题、三套样张、用户选择、口播、素材、镜头、审批、声音、质检与 SHA-256，使变化原因可回查。
