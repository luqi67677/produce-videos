---
name: produce-videos
description: 把讲稿、文档、截图、图片、PPT 或录屏制作成 16:9 横屏或 3:4 竖屏动态视频和独立封面。建立真实 0—2 秒叙事、平台安全区、项目级创作记忆和人物一致性，按风险合并确认包，同时保留口播、素材、声音、分镜、动态证明和成片质量门；可复用本地 TTS，缺失时经授权准备 Qwen3-TTS。适用于完整制作、续作和定点修改；只要求脚本、分镜或审查时不擅自渲染。
display_name: "视频生成与编辑"
display_name_en: "Produce Videos"
description_zh: "把文字和已有素材制作成经过逐步确认与质量检查的视频和独立封面"
description_en: "Turn scripts and source assets into reviewable, quality-gated videos and covers."
version: "2.5.0"
author: "produce-videos contributors"
---

# 2026-09-08 视频生成与编辑 V2.5.0

创建日期：2026-09-03

版本：V2.5.0

## 运行环境与兼容边界

- 本 Skill 使用通用的目录式 `SKILL.md` 结构；平台特定安装方式见 `README.md`。
- 完整执行需要 Agent 能读取和写入本地文件、运行 Python 与视频工具，并直接展示图片、音频和视频。缺少任一关键能力时，先说明限制和可交付范围，不得把“读过仓库”当成安装或成片完成。
- 不依赖 Codex 专属命令作为工作流前提。平台原生调用语法只用于启动 Skill，进入流程后统一依据本文件和相对路径资源执行。

## 开源边界

- 不内置任何个人形象、私人参考音频、私人水印、账号资料或本机绝对路径。
- 用户提供的品牌、人物、声音和素材只属于当前项目；先确认授权，不得写回 Skill 包。
- 创作记忆默认只存在当前项目；只有用户明确授权并指定 Skill 外工作区时才可跨项目复用。
- 不默认假设品牌色、人物角色、水印或固定音色。
- 内置模板只负责提供视觉系统候选；最终主题由用户选择一次，全片统一读取。

## 交付契约

- 用户要求“制作视频”时，交付可播放成片和一张独立 3:4 封面，不只交付脚本或方案；用户只要求脚本、分镜或审查时不擅自渲染。
- 保留上一个可用版本；修改产生新版本，不覆盖已交付文件。
- 用户明确给出的时长优先。没有目标时按平台、内容密度和观看场景推断保守范围；只有时长会显著改变成本或叙事时才追问。超过合理上限时压缩主线或拆条，不靠不自然加速声音硬塞。
- 竖屏统一使用 3:4、1080×1440、30fps；横屏使用 16:9、1920×1080、30fps。独立封面始终使用 3:4、1080×1440。
- 只宣传资料可支持的事实；本地输出、上传、草稿、发布和真实用户效果必须分开表述。

## 不可压缩的底线

1. 第一次开工就分别锁定口播内容来源和最终声音来源，并一次补齐平台、画幅、时长、素材、TTS 能力与声音方向；复用用户已经说明的信息，后续不得重复询问已确认字段。用户只要求脚本、分镜或审查时停在该步。
2. 先核验事实与口播，不让视觉替内容背书；本地输出、上传、草稿、发布和真实用户效果分开表述。
3. 用户没有视觉方向时，先验证完整 34 套主题目录并对全部主题评分，再输出三套同内容、同画幅的真实候选；用户已有视觉系统时直接验证并锁定。主题回答“长什么样”，88 套布局回答“内容放在哪里”，不得混为一套模板数量。
4. 候选内容帧达到校准质量，选中后成为全片唯一版式基线；封面、字幕、分镜、动画和成片共同读取 `video-style-theme.json`。
5. 用户确认的标题逐字保留；只有明确批准另一封面标题时才能改写。中文混排使用中文优先字体并保持品牌原始大小写；最终字体加载后必须按真实容器宽度自适应断行，不得出现只剩一两个字的孤行。
6. 真实、官方和已授权素材优先；生成素材只补明确缺口。隐私按 `privacy_targets` 逐镜定位，只遮实际出现的最小区域。
7. 音频先复用用户选择的来源和声音方向；本地模型只做有限发现，缺失时取得授权后才下载。正式旁白必须绑定实际文件、SHA-256、时长、采样率、声道、声音选择和连续时间戳。
8. 一段口播只绑定一个镜头；镜头必须展示同一对象、动作与结果。静态分镜是渲染契约，成片不得退回原始素材轮播。
9. 字幕只有一个最终渲染层；动画由旁白语义驱动，不用晃动、循环、重复贴图或无关装饰填满时间。
10. 新项目使用一个 `approval-ledger.json` 保存五个机器阶段；每条记录覆盖本阶段真实文件及 SHA-256。旧项目独立审批文件继续兼容。
11. 图片、音频和视频必须直接展示；HTML 只能辅助。用户无法查看时暂停当前确认并换成可见、可播放产物。
12. 样片或预览、正式母版分别运行 render gate；画幅、时长、音轨、旁白绑定、黑帧和响度硬失败必须修复。
13. 视觉干净度是硬门：生成与合成画面默认无地面、无地平线、无投射阴影和悬浮阴影；主体需要分离时只使用柔和克制的轮廓光。脏色叠加、重色字幕条、整页截图卡片、多套材质混用或残留裁切元素均先返工，不进入分镜和动态预览。
14. A-roll 是声音与叙事主轴，B-roll 是绑定当前口播的证据或解释，不是装饰。每个 B-roll 必须填写 `covers`；每个切换必须记录前后状态、连续性锚点与理由。默认硬切，不为转场效果本身制造镜头。
15. 已有音视频需要重剪时，词级转写、画面轨、A/B-roll、素材入点、时间线位置和转场统一写入 `edit-decision-list.json`；渲染、节拍吸附与可编辑时间线导出都读取它，不建立第二套剪辑时间。
16. 信息流短视频在 0—2 秒内给出可证结果、反差、真实冲突、具体问题或操作证据；中段只推进一条核心张力，结尾兑现开头承诺。不得为了吸引而制造假失败或假危机。
17. 每个发布平台必须绑定安全区配置；抖音竖屏默认审查顶部 12%、底部 24%、右侧 16% 的保守遮挡区，并生成可关闭的 UI 审查层。用户提供近期平台截图时，以项目内校准值覆盖内置保守值。
18. 反复出现的真人、品牌角色或生成人物必须先锁定用户定义的 `character-profile.json`；A-roll、B-roll、封面和补图共用同一 `character_id`，未确认身份锚点前不批量生成。
19. 创作记忆只保存经用户确认的可复用规则、退役规则和证据哈希；当前项目进度仍只从审批账本推导，不创建第二套状态。
20. 代表性微样片只能证明该运动语法可用，不能替整片背书。完整低清预览必须逐镜审计：时长超过 1.2 秒的镜头至少有一次由口播触发的语义变化；三项及以上列表、步骤或流程必须按口播顺序分段建立并保持，整页一次性出现、静止图片持有或统一整页漂移均不得通过。
21. 章节只负责叙事分组，不能代替剪辑镜头。新项目使用 `shot-readiness.json` V2.6，把全部剪辑镜头逐一绑定批准口播片段、真实审查帧、EDL 切点、版式、证据、人物动作和观众可见文字；未知 schema 直接失败，不能静默跳过新门禁。
22. 画面第一帧先保留稳定骨架或已批准主视觉，再按口播逐项揭示；不得先清空画面等待元素入场。制作说明、动作提示、隐私处理说明和“真实素材”等内部标签只存在契约中，不得渲染给观众。
23. 同一人物保持身份，不复用不合场景的姿势。每个含人物镜头都要写场景动作、动作签名和服装语境；重复动作必须有经审查的叙事理由，封面人物也必须服务标题而不是任意摆拍。

## 风险分流

在 `video-brief.md` 记录 `workflow_mode` 和判断理由，选择最轻但足够安全的流程：

| 模式 | 适用条件 | 用户确认节奏 |
|---|---|---|
| `fast` | 通常不超过 30 秒；事实稳定；无反复生成人物、敏感录屏或授权疑点；使用成熟主题和运动语法 | 完整低清预览同时承担动态证明 |
| `standard` | 普通宣传片、教程或混合素材；需要 TTS；风险可控 | 默认 4—5 个确认包；蓝图通过后先做代表性微样片，机器和 Agent 检查通过即继续 |
| `high-risk` | 反复生成人物、敏感录屏、授权不明、强事实主张、超过 90 秒、首次运动语法或需要下载安装 | 先审人物锚点/高风险原始素材，并单独确认短动态样片 |

风险升高时可以升级模式并说明原因；不得为了少问一步静默降级。

## 审查交付规则

进入确认节点前读取 `references/review-system.md`。每轮只展示一个完整确认包和一个总问题；同一包可以包含紧密相关的多个项目，但必须分别显示状态和允许逐项修改。收到回复后先写审批账本并校验，再开始依赖这些批准的工作；不依赖该选择的只读检查和准备工作可以并行。

## 执行流程

### 1. 开工信息包

开始时同时读取 `assets/format-presets.json`、`assets/platform-overlay-profiles.json`、`assets/video-brief-template.md` 和 `references/audio-system.md`，建立 `video-brief.md`。口播内容来源与最终声音来源是两个独立问题，不能互相代替。

- 用户已说明的字段直接记录，只把所有缺项合并成一次开工问题，不逐项追问。至少锁定平台与遮挡配置、画幅、时长、口播内容来源、最终声音来源、TTS 资源状态、声音方向、静态补图策略、历史成片/创作记忆，以及是否反复使用同一人物。
- 口播内容来源只选一条：已有确定稿、AI 根据资料撰写、从已有音视频转写，或明确无口播。
- 最终声音来源只选一条：已有独立口播音频、从已有视频提取、已有 TTS API、已有本地 TTS 模型、准备免费的 Qwen3-TTS，或明确无旁白。
- 已有独立音频或视频内音频时，开工信息包就记录真实文件；已有 API 时记录供应方和凭证所在的安全位置；已有本地模型时记录已知目录或允许检查的标准缓存；用户不确定本机是否有模型并要求检查时，立即在标准缓存和明确目录中做有限只读发现，再锁定声音路线；需要 TTS 时同时收集性别呈现、年龄感、气质、能量、语速和禁忌特征。
- 什么都没有、或开工阶段有限发现没有兼容模型，且用户选择 AI 配音时，立即展示 `assets/qwen-tts-models.json` 中的官方来源、当前执行器对应模型、大小、平台要求、依赖安装和下载命令。安装依赖与下载模型仍作为单独授权问题，但必须在开工阶段提出，不能做到配音环节才告知。
- 静态补图策略只选一条：`pending`、`user-assets-only` 或 `allow-generated-stills`。选择生成静态补图时必须在开工信息包中记录用户批准；这只授权生成静态插画、物体图、背景图或信息图，不授权生成视频，也不授权伪造产品结果、数据或真实背书。
- 记录 `workflow_mode`、判断理由、禁用词、隐私目标、授权边界和输出目录。运行 `python3 scripts/validate_startup_brief.py <项目目录>/video-brief.md --require-approved`；未通过时不得进入内容方向包。
- 只有用户提供已确认历史成片或授权创作记忆时才读取；先提炼“继续使用 / 本次实验 / 不再使用”，不自动将单次成片的所有选择固化。
- 除用户选择或明确要求检查本地模型时的有限只读发现外，不因建立 brief 自动扫描；不下载、不调用云端服务，也不生成下游产物。

### 2. 内容方向包

按需读取 `references/content-to-video-orchestration.md`、`references/director-workflow.md`、`references/narrative-continuity-system.md`、`references/creator-memory-and-identity.md` 和 `references/visual-style-system.md`。

1. 从资料建立 `claims-ledger.md`、完整 `master-script.json` 和 `story-contract.json`；区分事实、推断、演示数据和待核验项。信息流短视频的开头在 0—2 秒内给出可证结果、反差、问题或操作证据，中段只推进一条核心张力，结尾回应开头。
2. 建立 `source-assets.json`，记录真实文件、SHA-256、来源、授权、用途、隐私目标和联系表；没有真实素材时记录生成边界。
3. 验证 34 套主题目录和 88 套布局目录。机器侧为全部主题记录分数、结论和简短理由码，只为入围 A/B/C 写详细理由；布局在逐镜排版时按信息结构选择并完成横竖屏适配。
4. 三套候选使用同一标题、同一代表内容、同一主视觉和目标画幅，分别输出 3:4 封面帧、内容帧、270×360 缩略图和完整总览图。
5. 候选内容帧必须达到校准画面质量并通过视觉干净度硬门；用户选中后直接作为版式基线。只有选中后仍需内容特定调整时才补校准画面。

`fast/standard` 把完整口播、叙事摘要、真实素材联系表和三套风格放入一个确认包。提示用户按“内容和素材通过，选 B”回复；单独的 `B` 只表示选择风格，不自动批准口播和素材。`high-risk` 先单独确认隐私、授权和禁止使用项。

批准后：

- 在 `approval-ledger.json` 写入 `script` 与 `source-assets`；
- 在 `visual-style-options.json` 记录用户原话和选择；
- 锁定 `video-style-theme.json`；
- 先校验账本、选择和主题，再生成依赖这些决定的内容。

### 3. 声音执行与确认包

只执行开工信息包已经锁定的路线，不再询问“声音从哪里来”。需要 TTS 时重新读取 `references/audio-system.md`。

- 已有独立成品口播：登记实际文件及技术信息，不增加试听步骤。
- 已有视频内口播：从已确认视频提取第一条目标音轨，检查是否确为干净可用的人声，再按 `external` 登记；不能把含背景音乐或多人混音的轨道静默当成正式旁白。
- 已有 TTS API：只通过环境变量或安全存储读取凭证，最小预检后按声音方向生成试听。
- 已有本地模型：用户选择该路线后才有限发现模型和兼容 Python。唯一兼容候选直接推荐并预检；多个能力差异明显的候选才让用户选择。
- 没有可用方案：必须直接展示 `assets/qwen-tts-models.json` 中的 Qwen3-TTS 免费开源模型地址、预计大小、依赖和目标目录，不只说“未找到模型”；单独取得授权后才安装或下载。
- 用户原话已完整覆盖性别呈现、年龄感、气质、能量、语速和禁忌特征时，直接建立已确认 `voice-brief.json`；只有 Agent 补充了实质推断时才再次回显确认。
- 默认生成三条同文案试听，只改变次要维度。用户明确选定后写入 `voice-selection.json`，才能生成完整旁白。

正式音频必须回填 `narration-contract.json` 的实际文件、SHA-256、时长、采样率、声道和连续场景时间戳；试听和正式旁白使用同一模型、声音描述和运行环境。

### 4. 成片蓝图包

按需读取 `references/layout-system.md`、`references/roll-and-transition-system.md`、`references/editing-system.md`、`references/director-workflow.md` 和 `references/implementation.md`。

- 先把每段标记为 `a-roll`、`b-roll`、`hybrid` 或 `graphic-led`。A-roll 锁定正在听谁、看什么主线；B-roll 必须填写 `covers`、切入理由和返回策略，不能用无关插画或通用 AI 画面填空。
- 素材不足时按“用户真实素材 → 官方素材 → 已核验关键帧 → 已授权静态补图 → 可编辑代码动画 → 纯文字/保留主轴”处理；不得调用视频生成模型。没有补图授权时，把全部缺口合并成一次确认。
- 每个转场记录上一个结束状态、下一个开始状态、连续性锚点和理由。默认硬切；只有形状、动作或方向能连续时使用匹配剪辑，只有确有逻辑缺口时使用图形桥接。
- 已有音视频需要重剪时，先用 `scripts/transcribe_media.py` 生成词级时间戳，再建立 `edit-decision-list.json`。切点不得落在词中；BGM 卡点只移动未锁定边界，不改变声音主轴和总时长。
- 从 `assets/asset-review-plan-template.json` 建立 `asset-review-plan.json`。低风险原始素材联系表与完整分镜合并审查；反复人物、品牌身份、隐私、授权或真实证据风险改用 `risk-first`，先确认原图和身份锚点再批量排分镜。
- 反复人物必须建立并锁定项目内 `character-profile.json`；一旦锁定，A-roll、B-roll、封面和补图全部按同一 `character_id` 调用。
- 完成全部镜头素材、独立封面草图、`asset-manifest.md`、素材复用关系、`shot-readiness.json`、`edit-decision-list.json`（需要剪辑时）和全量静态分镜。
- 章节可包含多个剪辑镜头；每个剪辑镜头只能绑定一个连续口播片段。使用 `shot-readiness.json` V2.6 的 `shots` 逐一写明时间范围、口播原文、叙事职责、真实审查帧、A/B-roll 职责、人物 ID、布局复核、证据、观众文案、内部制作备注和语义切点。
- `rendered_text` 只放观众确实要读的文字；动作说明、构图意图、马赛克说明、素材来源标签和其他导演备注只放 `production_notes`。能力与结果主张必须绑定完整可辨的真实预览或已验证结果，不能用空框、裁残截图或文字口号代替。
- 用 `edit-decision-list.json` V1.1 保存与逐镜表完全相同的口播片段和切点；运行 `scripts/validate_timeline_sync.py` 后才允许渲染，确保上一句说完再进入下一画幅。
- 竖屏平台分镜额外生成一张可关闭的 UI 遮挡审查图；遮挡层不进入成片，关闭后也必须保持关键内容安全。
- 以目标画幅分镜联系表为主审查产物，让用户在真实构图中检查素材用法；素材清单和复用矩阵作为追溯附件，不再脱离分镜增加一次审查。
- 用户批准一个成片蓝图包后，在账本分别写入 `assets` 和 `storyboard`，各自绑定实际文件与 SHA-256。
- `high-risk` 中仍有授权或隐私不确定项时，先独立批准这些素材，再排分镜。

### 5. 最终预览包

读取 `references/motion-system.md` 和 `references/quality-gates.md`。

- `fast`：只有成熟运动语法、无反复生成人物且无平台/隐私疑点时，用完整低清预览同时承担动态证明。
- `standard`：蓝图通过后先做 4—8 秒代表性微样片，检查主题、最终声音、单层字幕、人物一致性、平台安全区和实际运动。机器与 Agent 通过后自动继续完整低清预览；样片暴露创意偏差时才停止请用户判断。
- `high-risk` 或首次运动语法：先做 4—8 秒最短样片并给用户单独确认；通过后再生成完整低清预览。
- 若计划样片超过预计成片的 40%，跳过短样片，直接生成完整低清预览。
- 低清预览与母版使用同一原生坐标、主题、旁白、字幕、真实素材和运动契约，只降低输出分辨率或码率。
- 从 `assets/motion-plan-template.json` 建立逐镜运动计划。每镜第一帧先有稳定骨架或主视觉；只有经审查的叙事需要才允许短暂留白，并写明原因。
- 完整低清预览生成后运行 `scripts/analyze_motion_coverage.py`，把视频、EDL 和运动计划的 SHA-256、逐镜有效变化次数、最长静止段、欠填充时长、静态镜头和分段揭示失败写入审计 JSON；任一应动镜头无语义变化、三项以上内容未分段建立、存在等待入场的空白帧或运动计划与 EDL 漂移，都不得进入 `motion` 审批。
- 直接展示可播放预览和联系表。用户批准后在账本写入 `motion`，再运行 full 门禁导出正式母版。
- 正式母版运行 `video_preflight.py` 并人工检查事实、隐私、授权、文字、字幕安全区、遮挡、镜头连续性和独立封面。

### 6. 修改既有成片

在 `shot-readiness.json.revision_scope` 锁定基线、用户反馈、受影响镜头和必须保持不变的镜头。先确认局部原尺寸帧、联系表或短样片，再重新生成完整低清预览。

只让实际受影响的下游失效：

| 变化 | 必须重做 | 默认保留 |
|---|---|---|
| `display_text` 改动 | 受影响口播、音频时间轴、相关镜头与预览 | 未变化素材授权、主题、无关镜头 |
| 更换声音或语速 | 正式音频、字幕时间轴、镜头时长与预览 | 口播文字、素材、主题和构图 |
| 替换某项素材 | 该素材审批、相关镜头、隐私复核与预览 | 无关镜头、口播、声音和主题 |
| 更换主题 | 主题选择、版式、分镜与预览 | 口播、已授权素材和声音 |
| 只改某个镜头 | 该镜头局部预览和全片预览 | 其余镜头的已批准基线 |

## 标准产物

项目至少保留：brief、主张账本、叙事契约、完整口播、真实素材清单、原始素材审片计划、视觉候选、唯一主题、需要时的创作记忆和人物档案、声音需求与选择、旁白契约、V2.6 逐镜就绪表、V1.1 EDL、运动计划与运动覆盖、V2 审批账本、平台遮挡审查图、分镜、代表性微样片、完整低清预览、正式视频、质检报告和联系表。

每条完整视频都交付一张 1080×1440 独立封面和 270×360 缩略图。读取 `assets/cover-brief-template.md` 并建立 `cover-contract.json`：主标题说明目标用户/场景与痛点或结果，副标题说明 Skill 差异，Skill 名称保持原始大小写并形成清晰层级；人物动作和服装必须支持标题。运行 `scripts/validate_cover_contract.py`，不用横屏首帧裁切代替。使用 Remotion 时同时交付源码、锁文件、素材清单和渲染命令；用户需要继续剪辑时从同一 EDL 导出 FCPXML，并说明哪些复杂合成已扁平化。
## 校验命令

```bash
python3 scripts/validate_theme_catalog.py \
  references/frontend-slides-themes/bold-template-pack/selection-index.json
python3 scripts/validate_layout_catalog.py
python3 scripts/doctor.py
python3 scripts/resume_project.py project
python3 scripts/validate_startup_brief.py project/video-brief.md --require-approved
python3 scripts/validate_creative_foundation.py project
python3 scripts/validate_timeline_sync.py project \
  --narration-contract project/narration-contract.json
python3 scripts/analyze_motion_coverage.py project/preview/video-preview.mp4 \
  project/edit-decision-list.json project/motion-plan.json project/motion-audit.json
python3 scripts/validate_cover_contract.py project/cover-contract.json
python3 scripts/validate_review_approval.py project/approval-ledger.json \
  --require-stage script --require-approved
python3 scripts/validate_render_gate.py project --mode sample \
  --narration-contract project/narration-contract.json
python3 scripts/validate_render_gate.py project --mode full \
  --narration-contract project/narration-contract.json
python3 scripts/video_preflight.py project/final/video.mp4 --orientation portrait --max-duration 180 \
  --narration-contract project/narration-contract.json --require-narration-binding
python3 scripts/scan_release.py
```

各阶段的模型发现、声音、版式和分镜命令按需读取对应 reference，不在入口重复维护。

## 按需读取的参考

- 模板推荐与主题锁定：`references/visual-style-system.md`
- 内容到视频编排：`references/content-to-video-orchestration.md`
- 叙事冲突、0—2 秒开头与镜头连贯：`references/narrative-continuity-system.md`
- 历史经验记忆、人物一致性与原始素材分流：`references/creator-memory-and-identity.md`
- 导演与分镜：`references/director-workflow.md`
- 动画语法：`references/motion-system.md`
- 版式与安全区：`references/layout-system.md`
- 视觉干净度与构图预算：`references/visual-cleanliness-system.md`
- A-roll、B-roll 与镜头桥接：`references/roll-and-transition-system.md`
- 词级转写、节拍与可编辑时间线：`references/editing-system.md`
- 声音系统：`references/audio-system.md`
- 渲染实现：`references/implementation.md`
- 质量门：`references/quality-gates.md`
- 审查交付与短回复：`references/review-system.md`

## 禁止事项

- 不在内容方向确认前批量生图，不在最终预览批准前导出正式母版。
- 不用固定三套、空模板、色块或低质量样张冒充 34 套主题匹配，也不混合不同主题的设计语言；不把 88 套布局误称为 88 套视觉风格。
- 不擅自缩短用户已确认标题，不改变品牌原始大小写，不把模板页码、日期和内部标签搬进画面。
- 不把“需要出现什么画面”“本地路径已遮挡”“评论身份已遮挡”“真实素材”等制作说明渲染成观众文案；隐私只通过实际裁切或不透明马赛克完成。
- 不用空框、占位卡或只写结果名称的图形冒充分镜、样片、导出、布局数量等能力证明；口播声称可交付或有数量时，画面必须展示真实预览、真实结果或可核验的代表样本。
- 不把 PPT 整页、原始录屏轮播、循环重播、随机裁切、整页晃动或自动彩框当成镜头设计。
- 不给生成主体添加地面、地平线、投射阴影、悬浮阴影或地面反射；不把轮廓光做成霓虹描边、发光毛边或新的视觉主角。只有用户明确要求真实空间叙事时才能记录例外并重新确认样张。
- 不用设置页或通用预览冒充保存、同步、草稿或发布证据；不虚构真实截图、数据、界面和背书。
- 不把 B-roll 当装饰素材库，不使用随机人物敲电脑、发光 AI 大脑、漂浮图标、无关滚动和重复主视觉来填时间；写不出 `covers` 的镜头直接删除。
- 不为了卡点切断词、句子或操作结果，不让 B-roll 改变声音主轴或整片总时长，不让渲染器和 NLE 导出各自维护另一套切点。
- 不用整栏模糊代替精确隐私处理，不让渲染器和门禁读取不同旁白契约，不把项目私人资产复制回 Skill。
- 不把单次“成片通过”自动当成长期偏好，不把创作记忆当成当前项目进度，不跨项目搜索未授权的历史文件。
- 不在同一视频中为 A-roll、B-roll、封面和补图重新设计同一人物；不在身份锚点未确认时批量生成人物素材。
- 不把同一人物姿势复制到多个不同职责的镜头；不只靠左右翻转、位移或换道具伪装新动作，也不让人物穿着、姿态或手势脱离当前讲解场景。
- 不让动画从空白底图开始等待元素入场；保持稳定骨架，再让承担当前口播的内容适量进入。
