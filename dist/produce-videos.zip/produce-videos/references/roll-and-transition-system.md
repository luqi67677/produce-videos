# A-roll、B-roll 与镜头桥接

## 定义

- `a-roll`：主叙事画面。通常是主讲人、角色、主要访谈或持续的核心操作，也可以是无人物视频中承担主轴的确定性主画面。它决定观众正在听谁、看什么主线。
- `b-roll`：在同一声音主轴上临时切入或叠加的辅助画面。它用于给证据、解释概念、展示产品、隐藏必要跳剪或建立场景，不负责凭空创造第二条故事。
- `hybrid`：A-roll 仍以画中画或局部区域存在，同时 B-roll 展示证据或操作。
- `graphic-led`：没有可见 A-roll 的旁白驱动视频，图解、文字和代码动画本身承担主画面。不要为了凑 A-roll 生成一个虚假主持人。

A-roll 是“主轴”，B-roll 是“有理由的切走”。两者不要求机械地 A-B-A-B 轮换，也不要求固定覆盖比例。

## 何时切入 B-roll

只有至少满足一项时才切入：

1. 当前口播点名了一个产品、动作、文件、页面、数据或结果，需要让观众看见证据；
2. 抽象概念不借助图解就难以理解；
3. A-roll 有已批准的跳剪需要遮盖；
4. 两个叙事段之间缺少空间、动作或因果连接；
5. 节奏需要一次视觉变化，而且这个变化能推进信息。

每个 B-roll 镜头必须填写 `covers`，逐字或准确概括它解释的口播句。写不出 `covers` 就是填充画面，删除。

## 素材补缺顺序

1. 用户提供且已授权的真实素材；
2. 官方页面、官方截图、官方演示或可核验资料；
3. 从用户素材中裁出的准确关键帧或局部录屏；
4. 用户在开工信息中允许后，生成静态插画、物体图、背景图或信息图；
5. 用 SVG、Canvas、HTML 或 Remotion 制作可编辑代码动画；
6. 纯文字或留在 A-roll，不为“每句话都要有图”制造无关画面。

本 Skill 不调用视频生成模型。静态生成图只能说明概念和情绪，不能伪造产品界面、发布结果、数据、人物背书或真实事件。用户没有在开工阶段允许生成补图时，只列出缺口并一次确认，不逐镜打断。

## 切入、返回与桥接

- 每个切点先设计前后交接。有对象、形状、方向或动作可以连续匹配时使用 match cut、取景推进或物件桥接；没有连续对象时使用干净硬切。具体做法与连续三镜验收见 `directing-methods-and-creator-style.md`。
- insert cut 用于短暂展示细节或证据，声音主轴保持不变，画面看完即返回。
- graphic bridge 用于两个段落之间确有逻辑缺口时；只展示一个能解释变化的动作，不增加新概念。
- dissolve、光效擦除、随机缩放、甩镜和故障转场默认禁用。只有它们本身表达时间、空间或状态变化时才使用。
- 如果存在可见 A-roll，开头钩子和结尾判断默认留在主讲人或主轴画面；只有开头证据本身比人脸更强时才例外。
- B-roll 覆盖的是画面，不延长声音主轴。切入和返回后，整片时长必须保持一致。

每个转场记录：上一个可见结束状态、下一个开始状态、缺失的连接、保留的连续性锚点和转场理由。桥接的职责是让因果可读，不是制造 spectacle。

## 逐镜语义切点

- 章节用于组织叙事，真实切点必须写入 `shot-readiness.json` V2.6 的 `shots` 和 `edit-decision-list.json` V1.1；两者的镜头 ID、顺序、起止时间、口播片段、`roll_type` 与 `covers` 必须一致。
- 切点放在当前词组、句子或操作结果完成之后。下一镜的标题、对象或结论不能在上一句还没说完时提前出现。
- B-roll 覆盖期间声音主轴不变；返回 A-roll 或进入下一镜时，总时长必须连续，不能出现音频仍在说上一画面、画面已经讲下一件事的串页。
- 渲染前运行 `scripts/validate_timeline_sync.py`；任何未听审的语义边界、时间空洞、重叠或口播片段漂移都停止渲染。

## 借鉴来源与取舍

- 用户素材库中的 A-roll/B-roll 笔记把 A-roll 视为叙事与 IP 锚点、B-roll 视为演示与可视化；这个方向正确，但本 Skill 扩展为无人物和纯图形视频也可用的角色定义。
- [OpenChatCut talking-head guide](https://github.com/0xsline/OpenChatCut/blob/main/src/agent/skills/talking-head-guide/SKILL.md) 把 A-roll 剪辑建立在词级转写上，并把 B-roll 用于解释具体指代和遮盖跳剪。
- [Novoads B-roll overlay](https://github.com/novoads/agent-skills/blob/main/shared/skills/broll-overlay/SKILL.md) 强调 B-roll 是覆盖而非拼接、声音持续、总时长不变，并要求每个窗口绑定所解释的口播。
- [remotion-code-motion-explainer](https://github.com/vibe-motion/remotion-code-motion-explainer) 强调输入状态、动作、系统反应、可见结果和镜头接力。
- [story-video-director](https://github.com/zlbigger/story-video-director) 强调切换前后的空间、方向、光线和对象状态连续。

开源项目中的具体秒数或覆盖比例只作为特定样片经验，不写成普适硬规则。当前内容、平台、节奏和证据密度优先。
